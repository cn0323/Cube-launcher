/*
 * Cube Launcher
 * Copyright (C) 2026 重念
 * SPDX-License-Identifier: GPL-3.0-only
 */

namespace Launcher.Application.Accounts;

public enum MicrosoftAccountLoginFailureReason
{
    Unknown,
    NotConfigured,
    ApplicationNotAuthorized,
    TimedOut,
    GameOwnershipRequired,
    AuthenticationServerUnavailable,
    CredentialStorageFailed
}
