/*
 * Cube Launcher
 * Copyright (C) 2026 重念
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */

using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Threading;
using Launcher.App.Models;

namespace Launcher.App.Views.Shell;

public partial class ShellNavigationView : UserControl
{
    /// <summary>透镜直径，和 XAML 里的 Width/Height 保持一致。</summary>
    private const double LensSize = 60;

    /// <summary>长按多久进入拖拽。太短会和点击抢，太长会觉得拖不动。</summary>
    private static readonly TimeSpan HoldDelay = TimeSpan.FromMilliseconds(420);

    /// <summary>按住后手指抖动的容差，超过就判定为点击而不是长按。</summary>
    private const double JitterTolerance = 6;

    private readonly DispatcherTimer holdTimer;

    private int downloadTaskPulseDispatchQueued;
    private bool isDownloadTaskPulseRunning;
    private DateTimeOffset lastDownloadTaskPulseAt = DateTimeOffset.MinValue;
    private MainViewModel? viewModel;

    private bool isPointerDown;
    private bool isDragging;
    private Point pressOrigin;
    private Point dragOrigin;
    private double lensY = double.NaN;
    private int lensRetry;

    public ShellNavigationView()
    {
        InitializeComponent();

        holdTimer = new DispatcherTimer { Interval = HoldDelay };
        holdTimer.Tick += HoldTimer_OnTick;

        DataContextChanged += ShellNavigationView_DataContextChanged;
        Loaded += (_, _) => RefreshLens(animate: false);
        NavRoot.SizeChanged += (_, _) =>
        {
            var clamped = ClampDockOffset(DockOffset.X, DockOffset.Y);
            DockOffset.X = clamped.X;
            DockOffset.Y = clamped.Y;
            RefreshLens(animate: false);
        };
        DockBody.SizeChanged += (_, _) => RefreshLens(animate: false);
        Unloaded += (_, _) =>
        {
            AttachViewModel(null);
            holdTimer.Stop();
        };
    }

    private void ShellNavigationView_DataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        AttachViewModel(e.NewValue as MainViewModel);
    }

    private void AttachViewModel(MainViewModel? nextViewModel)
    {
        if (ReferenceEquals(viewModel, nextViewModel))
            return;

        if (viewModel is not null)
        {
            viewModel.NavigationItems.CollectionChanged -= NavigationItems_CollectionChanged;
            viewModel.DownloadTasksNavigationItem.PropertyChanged -= NavigationItem_PropertyChanged;
            viewModel.DownloadTasksPage.TaskStarted -= DownloadTasksPage_TaskStarted;

            foreach (var item in viewModel.NavigationItems)
                item.PropertyChanged -= NavigationItem_PropertyChanged;
        }

        viewModel = nextViewModel;

        if (viewModel is not null)
        {
            viewModel.NavigationItems.CollectionChanged += NavigationItems_CollectionChanged;
            viewModel.DownloadTasksNavigationItem.PropertyChanged += NavigationItem_PropertyChanged;
            viewModel.DownloadTasksPage.TaskStarted += DownloadTasksPage_TaskStarted;

            foreach (var item in viewModel.NavigationItems)
                item.PropertyChanged += NavigationItem_PropertyChanged;

            Dispatcher.BeginInvoke(() => RefreshLens(animate: false), DispatcherPriority.Loaded);
        }
    }

    private void NavigationItems_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        if (e.OldItems is not null)
        {
            foreach (NavigationItem item in e.OldItems)
                item.PropertyChanged -= NavigationItem_PropertyChanged;
        }

        if (e.NewItems is not null)
        {
            foreach (NavigationItem item in e.NewItems)
                item.PropertyChanged += NavigationItem_PropertyChanged;
        }

        RefreshLens(animate: false);
    }

    private void NavigationItem_PropertyChanged(object? sender, PropertyChangedEventArgs e)
    {
        if (e.PropertyName is not (nameof(NavigationItem.IsSelected) or nameof(NavigationItem.AvatarUrl)))
            return;

        if (e.PropertyName == nameof(NavigationItem.IsSelected))
            Dispatcher.BeginInvoke(() => RefreshLens(animate: true), DispatcherPriority.Loaded);
    }

    /* ------------------------------------------------------------------
       透镜定位
       ------------------------------------------------------------------ */

    private void RefreshLens(bool animate)
    {
        if (viewModel is null)
        {
            DockLens.Opacity = 0;
            return;
        }

        var selected = FindSelectedItem();
        if (selected is null)
        {
            DockLens.Opacity = 0;
            return;
        }

        var button = FindItemButton(DockBody, selected);
        if (button is null || button.ActualHeight <= 0)
        {
            // 容器还没生成好：下一帧再试，最多重试几次，避免无限排队
            if (lensRetry++ < 3)
                Dispatcher.BeginInvoke(() => RefreshLens(animate: false), DispatcherPriority.Loaded);

            return;
        }

        lensRetry = 0;

        var offset = button.TransformToAncestor(DockBody).Transform(new Point(0, 0));
        var target = offset.Y + ((button.ActualHeight - LensSize) / 2);

        MoveLens(target, animate);
        DockLens.Opacity = 1;
    }

    private NavigationItem? FindSelectedItem()
    {
        if (viewModel is null)
            return null;

        if (viewModel.DownloadTasksNavigationItem.IsSelected)
            return viewModel.DownloadTasksNavigationItem;

        foreach (var item in viewModel.NavigationItems)
        {
            if (item.IsSelected)
                return item;
        }

        return null;
    }

    private static Button? FindItemButton(DependencyObject root, object dataContext)
    {
        var count = VisualTreeHelper.GetChildrenCount(root);
        for (var i = 0; i < count; i++)
        {
            var child = VisualTreeHelper.GetChild(root, i);
            if (child is Button button && ReferenceEquals(button.DataContext, dataContext))
                return button;

            var nested = FindItemButton(child, dataContext);
            if (nested is not null)
                return nested;
        }

        return null;
    }

    private void MoveLens(double target, bool animate)
    {
        if (double.IsNaN(lensY))
            animate = false;

        lensY = target;

        if (!animate)
        {
            LensOffset.BeginAnimation(TranslateTransform.YProperty, null);
            LensOffset.Y = target;
            return;
        }

        var animation = new DoubleAnimation(target, TimeSpan.FromMilliseconds(430))
        {
            EasingFunction = new QuarticEase { EasingMode = EasingMode.EaseOut }
        };

        LensOffset.BeginAnimation(TranslateTransform.YProperty, animation, HandoffBehavior.SnapshotAndReplace);
    }

    /* ------------------------------------------------------------------
       长按拖动整条胶囊
       ------------------------------------------------------------------ */

    private void DockRoot_OnPreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
    {
        if (e.ChangedButton != MouseButton.Left)
            return;

        pressOrigin = e.GetPosition(NavRoot);
        dragOrigin = new Point(DockOffset.X, DockOffset.Y);
        isPointerDown = true;
        isDragging = false;
        holdTimer.Stop();
        holdTimer.Start();
    }

    private void HoldTimer_OnTick(object? sender, EventArgs e)
    {
        holdTimer.Stop();

        if (!isPointerDown || Mouse.LeftButton != MouseButtonState.Pressed)
        {
            isPointerDown = false;
            return;
        }

        BeginDrag();
    }

    private void BeginDrag()
    {
        isDragging = true;
        Mouse.Capture(DockRoot, CaptureMode.Element);

        // 拖起来的时候稍微“提”一下，能看出已经抓住整条了
        DockRoot.Opacity = 0.94;
        SetDockShadow(0.5);
        Cursor = Cursors.SizeAll;
    }

    private void DockRoot_OnPreviewMouseMove(object sender, MouseEventArgs e)
    {
        if (!isPointerDown)
            return;

        var now = e.GetPosition(NavRoot);
        var dx = now.X - pressOrigin.X;
        var dy = now.Y - pressOrigin.Y;

        if (!isDragging)
        {
            // 长按还没成立就先划走了，当成普通点击 / 滚动处理
            if (Math.Abs(dx) > JitterTolerance || Math.Abs(dy) > JitterTolerance)
                holdTimer.Stop();

            return;
        }

        var clamped = ClampDockOffset(dragOrigin.X + dx, dragOrigin.Y + dy);
        DockOffset.X = clamped.X;
        DockOffset.Y = clamped.Y;
        e.Handled = true;
    }

    private void DockRoot_OnPreviewMouseLeftButtonUp(object sender, MouseButtonEventArgs e)
    {
        holdTimer.Stop();
        isPointerDown = false;

        if (!isDragging)
            return;

        isDragging = false;
        Mouse.Capture(null);
        DockRoot.Opacity = 1;
        SetDockShadow(0.34);
        Cursor = Cursors.Arrow;

        // 松手这一下不要再触发一次导航
        e.Handled = true;
    }

    private void DockRoot_OnMouseLeave(object sender, MouseEventArgs e)
    {
        if (!isDragging)
            holdTimer.Stop();
    }

    /// <summary>
    /// XAML 里声明的 Effect 是冻结的，直接改属性会炸，所以克隆一份再调。
    /// </summary>
    private void SetDockShadow(double opacity)
    {
        if (DockRoot.Effect is not System.Windows.Media.Effects.DropShadowEffect current)
            return;

        var clone = current.Clone();
        clone.Opacity = opacity;
        DockRoot.Effect = clone;
    }

    private Point ClampDockOffset(double x, double y)
    {
        var hostWidth = NavRoot.ActualWidth;
        var hostHeight = NavRoot.ActualHeight;
        var dockWidth = DockRoot.ActualWidth;
        var dockHeight = DockRoot.ActualHeight;
        var left = DockRoot.Margin.Left;

        // 初始位置是「左边距 + 垂直居中」，位移为 0，所以可移动范围以 0 为基准上下对称
        var minX = -left;
        var maxX = Math.Max(minX, hostWidth - dockWidth - left);

        var verticalRoom = Math.Max(0, (hostHeight - dockHeight) / 2 - 8);
        var minY = -verticalRoom;
        var maxY = verticalRoom;

        return new Point(
            Math.Clamp(x, minX, maxX),
            Math.Clamp(y, minY, maxY));
    }

    /* ------------------------------------------------------------------
       下载任务脉冲（原有行为）
       ------------------------------------------------------------------ */

    private void DownloadTasksPage_TaskStarted(object? sender, DownloadTaskItem e)
    {
        if (Interlocked.Exchange(ref downloadTaskPulseDispatchQueued, 1) == 1)
            return;

        Dispatcher.BeginInvoke(TryRunDownloadTaskPulse, DispatcherPriority.Render);
    }

    private void TryRunDownloadTaskPulse()
    {
        Interlocked.Exchange(ref downloadTaskPulseDispatchQueued, 0);

        if (isDownloadTaskPulseRunning)
            return;

        var now = DateTimeOffset.UtcNow;
        if (now - lastDownloadTaskPulseAt < TimeSpan.FromMilliseconds(950))
            return;

        lastDownloadTaskPulseAt = now;
        RunDownloadTaskPulse();
    }

    private void RunDownloadTaskPulse()
    {
        const double initialOpacity = 1;
        isDownloadTaskPulseRunning = true;
        var duration = TimeSpan.FromMilliseconds(850);
        var easing = new CubicEase { EasingMode = EasingMode.EaseOut };

        DownloadTaskPulseCircle.BeginAnimation(UIElement.OpacityProperty, null);
        DownloadTaskPulseScale.BeginAnimation(ScaleTransform.ScaleXProperty, null);
        DownloadTaskPulseScale.BeginAnimation(ScaleTransform.ScaleYProperty, null);

        DownloadTaskPulseCircle.Opacity = initialOpacity;
        DownloadTaskPulseScale.ScaleX = 0.9;
        DownloadTaskPulseScale.ScaleY = 0.9;

        var opacityAnimation = new DoubleAnimation(initialOpacity, 0, duration)
        {
            EasingFunction = easing,
            FillBehavior = FillBehavior.Stop
        };
        opacityAnimation.Completed += (_, _) =>
        {
            DownloadTaskPulseCircle.BeginAnimation(UIElement.OpacityProperty, null);
            DownloadTaskPulseScale.BeginAnimation(ScaleTransform.ScaleXProperty, null);
            DownloadTaskPulseScale.BeginAnimation(ScaleTransform.ScaleYProperty, null);
            DownloadTaskPulseCircle.Opacity = 0;
            DownloadTaskPulseScale.ScaleX = 1;
            DownloadTaskPulseScale.ScaleY = 1;
            isDownloadTaskPulseRunning = false;
        };

        DownloadTaskPulseCircle.BeginAnimation(
            UIElement.OpacityProperty,
            opacityAnimation,
            HandoffBehavior.SnapshotAndReplace);

        var scaleAnimation = new DoubleAnimation(0.9, 1, duration)
        {
            EasingFunction = easing,
            FillBehavior = FillBehavior.Stop
        };
        DownloadTaskPulseScale.BeginAnimation(ScaleTransform.ScaleXProperty, scaleAnimation, HandoffBehavior.SnapshotAndReplace);
        DownloadTaskPulseScale.BeginAnimation(ScaleTransform.ScaleYProperty, scaleAnimation.Clone(), HandoffBehavior.SnapshotAndReplace);
    }
}
