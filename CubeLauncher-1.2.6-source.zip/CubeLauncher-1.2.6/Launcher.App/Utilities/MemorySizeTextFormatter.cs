/*
 * Cube Launcher
 * Copyright (C) 2026 重念
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */

using Launcher.App.Resources;

namespace Launcher.App.Utilities;

internal static class MemorySizeTextFormatter
{
    public static string Format(int memoryMb)
    {
        if (memoryMb >= 1024)
            return FormatGb(memoryMb);

        return string.Format(Strings.Settings_MemorySizeMbFormat, memoryMb);
    }

    public static string FormatGb(double memoryMb)
    {
        return string.Format(Strings.Settings_MemorySizeGbFormat, memoryMb / 1024d);
    }
}
