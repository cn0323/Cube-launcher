/*
 * Cube Launcher
 * Copyright (C) 2026 重念
 * SPDX-License-Identifier: GPL-3.0-only
 */

using System.Windows.Controls;

namespace Launcher.App.Views.Multiplayer;

public partial class JoinLobbyView : UserControl
{
    public JoinLobbyView()
    {
        InitializeComponent();
    }
}
