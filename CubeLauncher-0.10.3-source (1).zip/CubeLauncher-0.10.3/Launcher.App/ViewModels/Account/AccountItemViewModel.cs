/*
 * Cube Launcher
 * Copyright (C) 2026 重念
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */

using CommunityToolkit.Mvvm.ComponentModel;
using Launcher.Application.Accounts;
using Launcher.Domain.Models;

namespace Launcher.App.ViewModels.Account;

public sealed partial class AccountItemViewModel : ObservableObject
{
    public AccountItemViewModel(LauncherAccount account)
    {
        Account = account;
    }

    public LauncherAccount Account { get; }

    public string Id => Account.Id;

    public string DisplayName => Account.DisplayName;

    public string? Uuid => Account.Uuid;

    public bool IsOffline => Account.IsOffline;
    public LauncherAccountKind Kind => Account.Kind;

    public string AvatarUrl => Account.AvatarUrl;

    public MinecraftSkinModel? SkinModel => Account.SkinModel;

    [ObservableProperty]
    private bool isSelected;
}
