/*
 * Cube Launcher
 * Copyright (C) 2026 重念
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */

using Launcher.App.Resources;

namespace Launcher.App.ViewModels.Settings;

public static class SettingsInteractiveControlCatalog
{
    public static IReadOnlyList<SettingsInteractiveControlItem> Create()
    {
        return
        [
            new(Strings.Settings_ControlSecondaryMenuButton, Strings.Settings_ControlCategoryNavigation),
            new(Strings.Settings_ControlListPageItemButton, Strings.Settings_ControlCategoryNavigation),
            new(Strings.Settings_ControlDialogButton, Strings.Settings_ControlCategoryButton),
            new(Strings.Settings_ControlPrimaryButton, Strings.Settings_ControlCategoryButton),
            new(Strings.Settings_ControlDangerButton, Strings.Settings_ControlCategoryButton),
            new(Strings.Settings_ControlInlineIconButton, Strings.Settings_ControlCategoryButton),
            new(Strings.Settings_ControlSwitch, Strings.Settings_ControlCategoryToggle),
            new(Strings.Settings_ControlSlider, Strings.Settings_ControlCategoryInput),
            new(Strings.Settings_ControlComboBox, Strings.Settings_ControlCategorySelection),
            new(Strings.Settings_ControlTextBox, Strings.Settings_ControlCategoryInput),
            new(Strings.Settings_ControlMultilineTextBox, Strings.Settings_ControlCategoryInput),
            new(Strings.Settings_ControlSearchBox, Strings.Settings_ControlCategoryInput),
            new(Strings.Settings_ControlChoiceList, Strings.Settings_ControlCategorySelection),
            new(Strings.Settings_ControlVirtualizedList, Strings.Settings_ControlCategorySelection)
        ];
    }
}
