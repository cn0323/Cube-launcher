﻿/*
 * Cube Launcher
 * Copyright (C) 2026 重念
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, version 3.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program. If not, see <https://www.gnu.org/licenses/>.
 *
 * SPDX-License-Identifier: GPL-3.0-only
 */

namespace Launcher.App.Services;

public sealed class ImmediateUiDispatcher : IUiDispatcher
{
    public static ImmediateUiDispatcher Instance { get; } = new();

    private ImmediateUiDispatcher()
    {
    }

    public bool HasAccess => true;

    public void Post(Action action)
    {
        action();
    }

    public void PostAfterTransition(Action action)
    {
        action();
    }

    public Task PostAfterTransitionAsync(Action action)
    {
        action();
        return Task.CompletedTask;
    }

    public void Invoke(Action action)
    {
        action();
    }

    public Task InvokeAsync(Func<Task> action)
    {
        return action();
    }
}
