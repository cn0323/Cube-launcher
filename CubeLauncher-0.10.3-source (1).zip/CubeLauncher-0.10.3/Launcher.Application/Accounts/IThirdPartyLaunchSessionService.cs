/*
 * Cube Launcher
 * Copyright (C) 2026 重念
 * SPDX-License-Identifier: GPL-3.0-only
 */

namespace Launcher.Application.Accounts;

public interface IThirdPartyLaunchSessionService
{
    Task<ThirdPartyLaunchSession> CreateAsync(
        LauncherAccount account,
        CancellationToken cancellationToken = default);
}
