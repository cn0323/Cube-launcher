/*
 * Cube Launcher
 * Copyright (C) 2026 重念
 * SPDX-License-Identifier: GPL-3.0-only
 */

namespace Launcher.Application.Accounts;

public sealed class MicrosoftAccountLoginException : Exception
{
    public MicrosoftAccountLoginException(
        MicrosoftAccountLoginFailureReason reason,
        string message,
        Exception? innerException = null)
        : base(message, innerException)
    {
        Reason = reason;
    }

    public MicrosoftAccountLoginFailureReason Reason { get; }
}
